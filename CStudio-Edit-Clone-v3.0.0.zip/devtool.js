//console.log('Hello from -> Devtool');

const init = () => {
  try {
    const version = localStorage.getItem('resources-saver-version');
    if (version === '2' || version === '3') {
      return chrome.devtools.panels.create('CStudio', 'icon.gif', 'devtool.app.html', function (panel) {
        console.log('Content is loaded to panel', panel);
      });
    }

    if (version === '0.1.9') {
      return chrome.devtools.panels.create('CStudio', 'icon.gif', 'legacy/0.1.9/devtool.app.html', function (panel) {
        console.log('Content is loaded to panel', panel);
      });
    }

    return chrome.devtools.panels.create('CStudio', 'icon.gif', 'legacy/0.1.8/devtool.app.html', function (panel) {
      console.log('Content is loaded to panel', panel);
    });
  } catch {
    return chrome.devtools.panels.create('CStudio', 'icon.gif', 'legacy/0.1.8/devtool.app.html', function (panel) {
      console.log('Content is loaded to panel', panel);
    });
  }
};

init();
